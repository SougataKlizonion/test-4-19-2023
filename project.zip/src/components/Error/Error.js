import React from 'react'

const Error= () => {
  return (
    <div className='error'><h1>Login first</h1> </div>
  )
}

export default Error