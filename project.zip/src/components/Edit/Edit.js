import axios from "axios";
import React, { useEffect } from "react";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const Edit = () => {
  const { userId } = useParams();
  const [userdata, setUserData] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:2023/api/v1/user/${userId}`).then((result) => {
      setUserData(result.data); })
      console.log(userdata)
  })

  return (
    <div>
      <div className="main-register">
        <div className="sub-register">
          Update
          <form>
            <label className="reg-lable">Name</label>
            <li>
              <input
                className="reg-input"
                name="name"
                type="text"
              ></input>
            </li>
            <label className="reg-lable">Phone</label>
            <li>
              <input
                className="reg-input"
                name="phone"
                type="number"
              ></input>
            </li>
            <label className="reg-lable">Email</label>
            <li>
              <input
                className="reg-input"
                type="text"
                name="email"
              ></input>
            </li>
            <div className="pre-submit">
              <li>
                <input className="submit" type="submit"></input>
              </li>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Edit;
