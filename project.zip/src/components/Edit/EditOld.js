import axios from "axios";
import React, { useEffect } from "react";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const Edit = () => {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const { userId } = useParams();
  const [data, setData] = useState({});

  useEffect(() => {
    axios.get(`http://localhost:2023/api/v1/user/${userId}`).then((result) => {
      setData(result.data);
      setName(data.name);
      setEmail(data.email);
      setPhone(data.phone);
    });
  },[]);

const submitHandller = async (e) => {
    e.preventDefault();
    console.log({name, phone, email})
    try {
      const response = await axios.put(`http://localhost:2023/api/v1/edit/${userId}`, {name,email,phone,});
      if (response.data._id) {
        setData(response.data);
        // setTimeout(() => {
        //   alert("user updated sucessful");
        // }, 500);
        // setTimeout(() => {
        //   const nav = navigate("/home");
        // }, 1000);
      }
    } catch (error) {
      setMessage(error.response.data);
      setTimeout(() => {
        setMessage("");
      }, 2000);
    }
  };
  return (
    <div>
      <div className="error">{message}</div>
      <div className="main-register">
        <div className="sub-register">
          Update
          <form onSubmit={submitHandller}>
            <label className="reg-lable">Name</label>
            <li>
              <input
                className="reg-input"
                name="name"
                value={data.name}
                type="text"
                onChange={(e)=> {
                  setName(e.target.value)
                }}
              ></input>
            </li>
            <label className="reg-lable">Phone</label>
            <li>
              <input
                className="reg-input"
                name="phone"
                value={data.phone}
                type="number"
                onChange={(e)=> {
                  setPhone(e.target.value)
                }}
              ></input>
            </li>
            <label className="reg-lable">Email</label>
            <li>
              <input
                className="reg-input"
                type="text"
                name="email"
                value={data.email}
                onChange={(e)=> {
                  setEmail(e.target.value)
                }}
              ></input>
            </li>
            <div className="pre-submit">
              <li>
                <input className="submit" type="submit"></input>
              </li>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Edit;
